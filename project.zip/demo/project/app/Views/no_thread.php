                        <span class="glyphicon glyphicon-comment" style="font-size: 40rem; color: #e6e6e6; margin-top: 50px;"></span>
                    <a style="font-size: 6rem; color: grey;">Select a thread</a>
                </div>
            </div>
        </div>