            <div class="d-flex flex-fill container-fluid flex-column">    	
                <div class="d-flex flex-column star_post">
                    <div class="title">Title about the new star discussion postTitle about the new star discussion postTitle about the new star discussion post</div>
                    <h6>Category1</h6>
                    <a class="align-self-end sticky-bottom" href="#">
                        <span class="glyphicon glyphicon-trash"></span>
                    </a>
                </div>
                <div class="d-flex flex-column star_post">
                    <div class="title">Title</div>
                    <h6>Category1</h6>
                    <a class="align-self-end sticky-bottom" href="#">
                        <span class="glyphicon glyphicon-trash"></span>
                    </a>
                </div>
 
