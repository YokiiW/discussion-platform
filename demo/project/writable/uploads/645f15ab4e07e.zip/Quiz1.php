<?php

namespace App\Controllers;

/**
 *	Quiz 1, INFS3202/7202, Sem 1, 2023
 *	Student ID: 47586125
 *	Prac Session: Prac 2 (In Person)
 */
class Quiz1 extends BaseController
{   
    protected $helpers = ['form','date'];

    public function index()
    {      
        echo "Quiz 1 starts here!";
        echo view('input');
    }
    public function Quiz1Controller()
    {
        // Task 3 & 4 - WRITE YOUR CODE HERE

        $data['error'] = "";
        $username = $this->request->getVar('username');
        $email = $this->request->getVar('email');

        $rules = [
            ctype_alnum($username),
            strlen($username) >= 4,
            strlen($username) <= 20,
            filter_var($email, FILTER_VALIDATE_EMAIL)
        ];

        helper('cookie');
        $session = session();

        if ($rules) {
            set_cookie('var1', $username);
            $session->set('var2', $email);
            $username = strtoupper($username);
            date_default_timezone_set('America/New_York');
            $data = [$date = date("d/m/Y"),
            $time = date("h:i:sa"),
            $timezoneName = timezone_name_from_abbr("EST")];
        }
        echo view('output');
        

        // Task 3 & 4 - END
    }
}
