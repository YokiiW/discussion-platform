<html>
<head>
    <title>Data Input</title>
</head>
<body>
    <?= validation_list_errors() ?>
    <!-- Task 1 - WRITE YOUR CODE HERE -->
    <?= form_open('Quiz1/Quiz1Controller') ?>
        <div>
            <label for="username">Username</label><br/><br/>
            <input type="text" name="username"><br/><br/>
        </div>
        <div>
            <label for="email">Email</label><br/><br/>
            <input type="text" name="email">
        </div>

        <input type="submit" name="submit" value = "Submit"/>
    <?= form_close() ?>
    <!-- Task 1 - END -->
</body>
</html>
